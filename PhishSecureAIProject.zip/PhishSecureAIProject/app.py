from flask import Flask, render_template, request
app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Safely get 'email_content' from the form
        email_content = request.form.get('email_content', '').strip()
        if not email_content:
            error = 'Please enter the email content.'
            return render_template('index.html', error=error)

        # Placeholder for actual analysis function
        # Backend integration here
        analysis_result = analyze_email(email_content)

        return render_template('index.html', analysis_result=analysis_result)

    return render_template('index.html')


def analyze_email(email_content):
    """
    Placeholder function to simulate email analysis.
    API integration here.
    """
    if "suspicious" in email_content.lower() or "click here" in email_content.lower():
        return {
            'is_phishing': True,
            'verdict': 'This email appears to be a phishing attempt!',
            'reasons': [
                'Contains suspicious links.',
                'Urgent call to action.',
                'Sender address is not recognized.'
            ],
            'recommendations': 'Do not click any links and delete the email.'
        }
    else:
        return {
            'is_phishing': False,
            'verdict': 'This email appears to be safe.',
            'reasons': [
                'No suspicious content detected.'
            ],
            'recommendations': 'No action needed.'
        }


if __name__ == '__main__':
    app.run(debug=True)
